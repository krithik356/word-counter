a=input()
print(len(a))